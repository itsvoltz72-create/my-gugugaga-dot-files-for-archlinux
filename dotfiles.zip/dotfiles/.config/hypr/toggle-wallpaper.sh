#!/bin/sh

# Check if mpvpaper is currently paused
if ps aux | grep [m]pvpaper | grep -q "T"; then
    # It is paused, so resume it
    pkill -CONT mpvpaper
    notify-send "Wallpaper" "Resumed" -i video-display
else
    # It is running, so freeze it
    pkill -STOP mpvpaper
    notify-send "Wallpaper" "Paused (Power Saving)" -i video-display
fi
