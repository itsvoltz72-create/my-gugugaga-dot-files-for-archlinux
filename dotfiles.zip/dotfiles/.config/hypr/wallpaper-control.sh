#!/bin/sh

# Path to the Hyprland event socket
SOCKET_ADDRESS="/tmp/hypr/$HYPRLAND_INSTANCE_SIGNATURE/.socket2.sock"

# Function to check if the active workspace has open windows
check_windows() {
    # Counts windows on the current active workspace
    WINDOW_COUNT=$(hyprctl activeworkspace -j | jq '.windows')
    
    if [ "$WINDOW_COUNT" -gt 0 ]; then
        # Windows exist, pause mpvpaper
        pkill -STOP mpvpaper
    else
        # Workspace is empty, resume mpvpaper
        pkill -CONT mpvpaper
    fi
}

# Monitor Hyprland events in a loop
socat -U - UNIX-CONNECT:"$SOCKET_ADDRESS" | while read -r line; do
    case "$line" in
        # Trigger check when windows open, close, or focus changes
        openwindow*|closewindow*|movewindow*|workspace*)
            check_windows
            ;;
    )
done
